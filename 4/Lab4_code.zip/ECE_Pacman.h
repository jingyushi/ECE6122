/*
Author: Jingyu Shi
Class: ECE6122
Last Date Modified: Oct.29, 2020
Description:
Definition of Pacman
*/
#pragma once
#include "ECE_Mobile.h"

class ECE_Pacman : public ECE_Mobile
{
private:

public:
	ECE_Pacman();
	~ECE_Pacman();
};