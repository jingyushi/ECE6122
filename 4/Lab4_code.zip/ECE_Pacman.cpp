/*
Author: Jingyu Shi
Class: ECE6122
Last Date Modified: Oct.29, 2020
Description:
Implementation of Pacman class
*/
#include "ECE_Pacman.h"

ECE_Pacman::ECE_Pacman()
{
	x = 0.0;
	y = 0.0;
	dir = 0;
	color = 0;
}

ECE_Pacman::~ECE_Pacman()
{

}