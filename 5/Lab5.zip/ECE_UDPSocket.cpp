#include "ECE_UDPSocket.h"

// Function called by thread

void receiveSocketMsgs(ECE_UDPSocket* pUDpSocket)
{
    // Loop that waits on incoming messages

    // Insert message into list based on sequence number

}

ECE_UDPSocket::ECE_UDPSocket(unsigned short usPort) :m_usPort(usPort) 
{
    // Setup socket

    // Start thread that waits for messages 
    m_recvThread = std::thread(receiveSocketMsgs, this);


};

bool ECE_UDPSocket::getNextMessage(udpMessage& msg)
{ 



    return false; 
};

void ECE_UDPSocket::sendMessage(const std::string& strTo, const udpMessage& msg) 
{



};

void ECE_UDPSocket::sendCompositeMsg()
{


};

