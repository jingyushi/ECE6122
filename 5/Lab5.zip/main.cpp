#include <iostream>
#include "ECE_UDPSocket.h"

using namespace std;

int main(int argc, char** argv)
{
    std::string strLine;
    unsigned short usPortNum{ 65211 };
    // Get the command line parameters

    // Setup socket
    ECE_UDPSocket udpSocket(usPortNum);

    do
    {
        // Handle the interactions with the user
        cout << "Please enter a command: ";
        std::getline(std::cin, strLine);

        // Split up strLine using space delimiter

    } while (true);

    return 0;
}