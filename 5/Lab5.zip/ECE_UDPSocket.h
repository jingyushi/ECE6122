#pragma once

#include <thread>
#include <list>
#include <string>
#include <mutex>

#ifdef _WIN32
    /* See http://stackoverflow.com/questions/12765743/getaddrinfo-on-win32 */
    #ifndef _WIN32_WINNT
    #define _WIN32_WINNT 0x0501  /* Windows XP. */
    #endif
    #include <winsock2.h>
    #include <Ws2tcpip.h>

    #pragma comment (lib, "Ws2_32.lib")
#else
    /* Assume that any non-Windows platform uses POSIX-style sockets instead. */
    #include <sys/socket.h>
    #include <arpa/inet.h>
    #include <netdb.h>  /* Needed for getaddrinfo() and freeaddrinfo() */
    #include <unistd.h> /* Needed for close() */

    typedef int SOCKET;
#endif



struct udpMessage
{
    unsigned short nVersion;
    unsigned short nType;
    unsigned short nMsgLen;
    unsigned long lSeqNum;
    char chMsg[1000];
};


class ECE_UDPSocket
{
public:
    ECE_UDPSocket() = delete;

    ECE_UDPSocket(unsigned short usPort);

    bool getNextMessage(udpMessage& msg);

    void sendMessage(const std::string& strTo, const udpMessage& msg);

    // Other stuff
    void sendCompositeMsg();

private:
    unsigned short m_usPort;
    std::thread m_recvThread;
    std::list<udpMessage> m_msgs;
    std::list<sockaddr_in> m_lstSources;
    std::mutex m_mutex;
    // Whatever else you need

};

